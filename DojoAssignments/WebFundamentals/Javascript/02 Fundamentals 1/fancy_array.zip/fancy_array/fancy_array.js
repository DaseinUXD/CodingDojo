var names = ["James", "Jill", "Jane", "Jack"];

for (i = 0; i < names.length; i++)
{
    console.log(i +" -> " + names[i])
}
