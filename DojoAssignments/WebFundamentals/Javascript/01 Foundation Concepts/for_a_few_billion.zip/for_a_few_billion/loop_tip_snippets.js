var index = 2;
index = index + 1;
index++;
// index now holds a value of 4

var counter = 5;
counter = counter - 1; // counter now holds a value of 4
counter--; // counter is now 3
counter *= 6; // counter is 18
counter /= 2; // counter == 9

for (var num = 10; num > 2; num = num - 1)
{
    console.log('num is currently', num);
}
