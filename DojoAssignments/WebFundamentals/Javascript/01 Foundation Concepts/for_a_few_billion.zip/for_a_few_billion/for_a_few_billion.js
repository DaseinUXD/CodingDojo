var days = 1;
//days = days +1;

var sum = 0.01;
//sum = sum + sum;

for (days; days <=30; days++) {
    console.log("total on ", days, " is ", sum=sum+sum);
}
// 20 days to 10,000
// 37 days to 1 Billion
// 1030 days to Infinity
//