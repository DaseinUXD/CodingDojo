//number variables
var num1 = 10;
console.log("The First Number:", num1);
var num2 = 9;
console.log("The Second Number:", num2);
var num3 = 8;
console.log("The Third Number:", num3);
var num4 = 7;
console.log("The Fourth Number:", num4);

//string variables
var str1 = "hello";
console.log("The First String:", str1);
var str2 = "computer";
console.log("The Second String:", str2);
var str3 = "user";
console.log("The Third String:", str3);

//boolean variables
var boo1 = true;
console.log("The First Boolean:", boo1);
var boo2 = false;
console.log("The Second Boolean:", boo2);

// undefined variable
var undef = undefined;
console.log("The First Undefined:", undef);