
var daysUntilMyBirthday = 60;                                         // A
while (daysUntilMyBirthday > 30)                                      // B
{
    console.log(daysUntilMyBirthday + " days until my birthday. I can't wait that long!!!"); // C
    daysUntilMyBirthday = daysUntilMyBirthday - 1;                                     // D
}
while (daysUntilMyBirthday < 30)                                      // B
{
    console.log(daysUntilMyBirthday + " days until my birthday. It's getting closer..."); // C
    daysUntilMyBirthday = daysUntilMyBirthday - 1;                                     // D
}
while (daysUntilMyBirthday < 5)                                      // B
{
    console.log(daysUntilMyBirthday + " DAYS UNTIL MY BIRTHDAY!!!!"); // C
    daysUntilMyBirthday = daysUntilMyBirthday - 1;                                     // D
}
if (daysUntilMyBirthday = 0)
{
    console.log("Happy Birthday");
}
        // E
